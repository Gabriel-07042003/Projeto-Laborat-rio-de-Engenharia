package br.com.estagio.fx;

import java.sql.Date;
import java.util.List;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Cadastro manual de dados no banco sistema_empresas.
 * Ordem recomendada: Empresa e Estagiário primeiro; depois Contato e Contrato (dependem deles).
 */
public class App extends Application {

	private static final String SQL_EMPRESAS = "SELECT id, razao_social FROM dados_empresa ORDER BY razao_social";
	private static final String SQL_ESTAGIARIOS = "SELECT id, nome_completo FROM dados_estagiario ORDER BY nome_completo";

	@Override
	public void start(Stage stage) {
		EntidadePane[] paginas = { empresa(), contato(), estagiario(), contrato() };
		String[] menu = { "🏢   Empresas", "👤   Contatos", "🎓   Estagiários", "📄   Contratos" };

		StackPane conteudo = new StackPane();
		ScrollPane rolagem = new ScrollPane(conteudo);
		rolagem.setFitToWidth(true);

		VBox lateral = new VBox();
		lateral.getStyleClass().add("sidebar");
		Label marca = new Label("🎓  Sistema de Estágio");
		marca.getStyleClass().add("brand");
		Label marcaSub = new Label("Cadastro de dados");
		marcaSub.getStyleClass().add("brand-sub");
		lateral.getChildren().addAll(marca, marcaSub);

		ToggleGroup grupo = new ToggleGroup();
		ToggleButton[] botoes = new ToggleButton[paginas.length];
		for (int i = 0; i < paginas.length; i++) {
			ToggleButton b = new ToggleButton(menu[i]);
			b.getStyleClass().add("nav-button");
			b.setToggleGroup(grupo);
			b.setUserData(i);
			b.setMaxWidth(Double.MAX_VALUE);
			botoes[i] = b;
			lateral.getChildren().add(b);
		}
		Region espaco = new Region();
		VBox.setVgrow(espaco, Priority.ALWAYS);
		Label rodape = new Label("MySQL · sistema_empresas");
		rodape.getStyleClass().add("sidebar-footer");
		lateral.getChildren().addAll(espaco, rodape);

		grupo.selectedToggleProperty().addListener((obs, antigo, novo) -> {
			if (novo == null) {
				antigo.setSelected(true); // não deixa ficar sem página selecionada
				return;
			}
			EntidadePane pagina = paginas[(Integer) novo.getUserData()];
			conteudo.getChildren().setAll(pagina);
			pagina.recarregar();
			rolagem.setVvalue(0);
		});

		BorderPane raiz = new BorderPane();
		raiz.setLeft(lateral);
		raiz.setCenter(rolagem);

		Scene cena = new Scene(raiz, 1280, 800);
		cena.getStylesheets().add(App.class.getResource("/style.css").toExternalForm());

		stage.setTitle("Cadastro de dados - Sistema de Estágio");
		stage.setMinWidth(1050);
		stage.setMinHeight(650);
		stage.setScene(cena);
		stage.show();

		botoes[0].setSelected(true);
	}

	private EntidadePane empresa() {
		return new EntidadePane("Empresas", "Cadastre as empresas parceiras de estágio.", "dados_empresa", List.of(
				Campo.numero("CNPJ", "cnpj", true),
				Campo.texto("Razão social", "razao_social", true, 150),
				Campo.texto("Área de atuação", "area_atuacao", false, 100),
				Campo.texto("Cidade", "cidade", false, 100),
				Campo.numero("CEP", "cep", false),
				Campo.texto("E-mail", "email", false, 150),
				Campo.texto("Site", "site", false, 200),
				Campo.texto("Telefone", "fone", false, 30),
				Campo.texto("Trabalhe conosco", "trabalhe_conosco", false, 255)), null);
	}

	private EntidadePane contato() {
		return new EntidadePane("Contatos das empresas", "Pessoas de referência em cada empresa.", "contato_empresa", List.of(
				Campo.ref("Empresa", "empresa_id", true, SQL_EMPRESAS),
				Campo.texto("Nome do contato", "nome_contato", true, 150),
				Campo.texto("Cargo", "cargo_contato", false, 100),
				Campo.texto("Telefone", "fone_contato", false, 30),
				Campo.texto("Área / departamento", "area_departamento", false, 100),
				Campo.texto("LinkedIn", "linkedin", false, 255)), null);
	}

	private EntidadePane estagiario() {
		return new EntidadePane("Estagiários", "Dados acadêmicos e de contato dos estudantes.", "dados_estagiario", List.of(
				Campo.texto("Nome completo", "nome_completo", true, 150),
				Campo.numero("CPF", "cpf", true),
				Campo.texto("Telefone", "fone", false, 30),
				Campo.texto("E-mail", "email", false, 150),
				Campo.texto("Curso", "curso", false, 100),
				Campo.inteiro("Semestre", "semestre", false),
				Campo.texto("Período (Matutino, Vespertino, Noturno, Integral)", "periodo", false, 10)), null);
	}

	private EntidadePane contrato() {
		return new EntidadePane("Contratos de estágio", "Vincule um estagiário a uma empresa e defina o período.", "contrato_estagio", List.of(
				Campo.ref("Empresa", "empresa_id", true, SQL_EMPRESAS),
				Campo.ref("Estagiário", "estagiario_id", true, SQL_ESTAGIARIOS),
				Campo.data("Início do contrato", "inicio_contrato", true),
				Campo.data("Término do contrato", "termino_contrato", true),
				Campo.texto("Carga horária", "carga_horaria", false, 50),
				Campo.texto("Área / setor do estágio", "area_setor_estagio", false, 100),
				Campo.area("Funções e atividades", "funcoes_atividades", false, 65535),
				Campo.texto("Supervisor responsável", "supervisor_responsavel", false, 150),
				Campo.texto("Cargo do supervisor", "cargo_supervisor", false, 100)),
				valores -> {
					Date inicio = (Date) valores.get("inicio_contrato");
					Date termino = (Date) valores.get("termino_contrato");
					if (termino.before(inicio)) {
						throw new IllegalArgumentException("O término do contrato não pode ser anterior ao início.");
					}
				});
	}

	public static void main(String[] args) {
		launch(args);
	}
}
