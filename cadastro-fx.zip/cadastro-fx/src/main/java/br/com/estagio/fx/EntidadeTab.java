package br.com.estagio.fx;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;

/** Aba genérica: formulário de cadastro + tabela com os registros + exclusão. */
public class EntidadeTab extends Tab {

	public record Opcao(long id, String texto) {
		@Override
		public String toString() {
			return texto;
		}
	}

	private final String tabela;
	private final Consumer<Map<String, Object>> validador;
	private final Map<Campo, Control> controles = new LinkedHashMap<>();
	private final TableView<List<String>> grade = new TableView<>();
	private final Label status = new Label();

	public EntidadeTab(String titulo, String tabela, List<Campo> campos,
			Consumer<Map<String, Object>> validador) {
		super(titulo);
		this.tabela = tabela;
		this.validador = validador;
		setClosable(false);

		GridPane form = new GridPane();
		form.setHgap(10);
		form.setVgap(10);
		int linha = 0;
		int coluna = 0;
		for (Campo c : campos) {
			Control controle = criarControle(c);
			controles.put(c, controle);
			Label rotulo = new Label(c.rotulo() + (c.obrigatorio() ? " *" : ""));
			if (c.tipo() == Campo.Tipo.AREA) {
				if (coluna != 0) {
					linha++;
					coluna = 0;
				}
				form.add(rotulo, 0, linha);
				form.add(controle, 1, linha, 3, 1);
				linha++;
				continue;
			}
			form.add(rotulo, coluna * 2, linha);
			form.add(controle, coluna * 2 + 1, linha);
			coluna++;
			if (coluna == 2) {
				coluna = 0;
				linha++;
			}
		}

		Button salvar = new Button("Salvar");
		salvar.setOnAction(e -> salvar());
		Button limpar = new Button("Limpar");
		limpar.setOnAction(e -> limpar());
		Button atualizar = new Button("Atualizar lista");
		atualizar.setOnAction(e -> recarregar());
		Button excluir = new Button("Excluir selecionado");
		excluir.setOnAction(e -> excluir());
		HBox botoes = new HBox(10, salvar, limpar, atualizar, excluir);

		VBox raiz = new VBox(12, form, botoes, status, grade);
		raiz.setPadding(new Insets(15));
		VBox.setVgrow(grade, Priority.ALWAYS);
		setContent(raiz);

		setOnSelectionChanged(e -> {
			if (isSelected()) {
				recarregar();
			}
		});
	}

	// ---------------------------------------------------------------- controles

	private Control criarControle(Campo c) {
		switch (c.tipo()) {
			case AREA: {
				TextArea area = new TextArea();
				area.setPrefRowCount(3);
				area.setWrapText(true);
				return area;
			}
			case DATA:
				return new DatePicker();
			case REF: {
				ComboBox<Opcao> combo = new ComboBox<>();
				combo.setPrefWidth(280);
				combo.setPromptText("Selecione...");
				return combo;
			}
			default: {
				TextField campo = new TextField();
				campo.setPrefWidth(280);
				if (c.tipo() == Campo.Tipo.LONG) {
					campo.setPromptText("somente números");
				}
				return campo;
			}
		}
	}

	@SuppressWarnings("unchecked")
	private Object ler(Campo c, Control controle) {
		Object valor;
		try {
			switch (c.tipo()) {
				case AREA:
					valor = vazioParaNull(((TextArea) controle).getText());
					break;
				case LONG: {
					String digitos = ((TextField) controle).getText().replaceAll("\\D", "");
					valor = digitos.isEmpty() ? null : Long.parseLong(digitos);
					break;
				}
				case INTEIRO: {
					String texto = vazioParaNull(((TextField) controle).getText());
					valor = texto == null ? null : Integer.parseInt(texto);
					break;
				}
				case DATA: {
					LocalDate data = ((DatePicker) controle).getValue();
					valor = data == null ? null : Date.valueOf(data);
					break;
				}
				case REF: {
					Opcao opcao = ((ComboBox<Opcao>) controle).getValue();
					valor = opcao == null ? null : opcao.id();
					break;
				}
				default:
					valor = vazioParaNull(((TextField) controle).getText());
			}
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException(c.rotulo() + ": número inválido.");
		}
		if (valor == null && c.obrigatorio()) {
			throw new IllegalArgumentException(c.rotulo() + " é obrigatório.");
		}
		if (valor instanceof String s && c.max() > 0 && s.length() > c.max()) {
			throw new IllegalArgumentException(
					c.rotulo() + " deve ter no máximo " + c.max() + " caracteres (tem " + s.length() + ").");
		}
		return valor;
	}

	private static String vazioParaNull(String s) {
		if (s == null || s.isBlank()) {
			return null;
		}
		return s.trim();
	}

	// ---------------------------------------------------------------- ações

	private void salvar() {
		try {
			Map<String, Object> valores = new LinkedHashMap<>();
			for (Map.Entry<Campo, Control> e : controles.entrySet()) {
				valores.put(e.getKey().coluna(), ler(e.getKey(), e.getValue()));
			}
			if (validador != null) {
				validador.accept(valores);
			}
			String sql = "INSERT INTO " + tabela + " (" + String.join(", ", valores.keySet()) + ") VALUES ("
					+ String.join(", ", Collections.nCopies(valores.size(), "?")) + ")";
			try (Connection cn = Db.get();
					PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
				int i = 1;
				for (Object v : valores.values()) {
					if (v == null) {
						ps.setNull(i++, Types.NULL);
					} else {
						ps.setObject(i++, v);
					}
				}
				ps.executeUpdate();
				try (ResultSet chaves = ps.getGeneratedKeys()) {
					long id = chaves.next() ? chaves.getLong(1) : -1;
					ok("Registro salvo em " + tabela + " (id=" + id + ").");
					System.out.println("[INSERT] " + tabela + " id=" + id + " -> " + valores);
				}
			}
			limpar();
			carregarGrade();
		} catch (IllegalArgumentException ex) {
			erro(ex.getMessage());
		} catch (SQLException ex) {
			erro("Erro no banco: " + ex.getMessage());
		}
	}

	private void excluir() {
		List<String> selecionado = grade.getSelectionModel().getSelectedItem();
		if (selecionado == null) {
			erro("Selecione uma linha na tabela para excluir.");
			return;
		}
		String id = selecionado.get(0);
		Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION,
				"Excluir o registro id=" + id + " de " + tabela + "?", ButtonType.YES, ButtonType.NO);
		confirmacao.setHeaderText(null);
		confirmacao.showAndWait().filter(b -> b == ButtonType.YES).ifPresent(b -> {
			try (Connection cn = Db.get();
					PreparedStatement ps = cn.prepareStatement("DELETE FROM " + tabela + " WHERE id = ?")) {
				ps.setLong(1, Long.parseLong(id));
				ps.executeUpdate();
				ok("Registro id=" + id + " excluído.");
				carregarGrade();
			} catch (SQLException ex) {
				if (ex.getErrorCode() == 1451) {
					erro("Não é possível excluir: existem registros vinculados a este (ex.: contratos).");
				} else {
					erro("Erro no banco: " + ex.getMessage());
				}
			}
		});
	}

	private void limpar() {
		for (Control c : controles.values()) {
			if (c instanceof TextField t) {
				t.clear();
			} else if (c instanceof TextArea a) {
				a.clear();
			} else if (c instanceof DatePicker d) {
				d.setValue(null);
			} else if (c instanceof ComboBox<?> cb) {
				cb.getSelectionModel().clearSelection();
				cb.setValue(null);
			}
		}
	}

	// ---------------------------------------------------------------- carga de dados

	/** Recarrega as opções dos combos (chaves estrangeiras) e a tabela. */
	public void recarregar() {
		carregarOpcoes();
		carregarGrade();
	}

	@SuppressWarnings("unchecked")
	private void carregarOpcoes() {
		for (Map.Entry<Campo, Control> e : controles.entrySet()) {
			if (e.getKey().tipo() != Campo.Tipo.REF) {
				continue;
			}
			ComboBox<Opcao> combo = (ComboBox<Opcao>) e.getValue();
			Opcao anterior = combo.getValue();
			List<Opcao> opcoes = new ArrayList<>();
			try (Connection cn = Db.get();
					Statement st = cn.createStatement();
					ResultSet rs = st.executeQuery(e.getKey().refSql())) {
				while (rs.next()) {
					opcoes.add(new Opcao(rs.getLong(1), rs.getString(2)));
				}
			} catch (SQLException ex) {
				erro("Erro ao carregar opções: " + ex.getMessage());
				return;
			}
			combo.setItems(FXCollections.observableArrayList(opcoes));
			if (anterior != null) {
				opcoes.stream().filter(o -> o.id() == anterior.id()).findFirst().ifPresent(combo::setValue);
			}
		}
	}

	private void carregarGrade() {
		try (Connection cn = Db.get();
				Statement st = cn.createStatement();
				ResultSet rs = st.executeQuery("SELECT * FROM " + tabela + " ORDER BY id DESC")) {
			ResultSetMetaData md = rs.getMetaData();
			int n = md.getColumnCount();
			grade.getColumns().clear();
			for (int i = 0; i < n; i++) {
				final int idx = i;
				TableColumn<List<String>, String> col = new TableColumn<>(md.getColumnLabel(i + 1));
				col.setCellValueFactory(cd -> new SimpleStringProperty(cd.getValue().get(idx)));
				grade.getColumns().add(col);
			}
			List<List<String>> linhas = new ArrayList<>();
			while (rs.next()) {
				List<String> linha = new ArrayList<>();
				for (int i = 1; i <= n; i++) {
					String s = rs.getString(i);
					linha.add(s == null ? "" : s);
				}
				linhas.add(linha);
			}
			grade.setItems(FXCollections.observableArrayList(linhas));
		} catch (SQLException ex) {
			erro("Erro ao ler " + tabela + ": " + ex.getMessage());
		}
	}

	// ---------------------------------------------------------------- mensagens

	private void ok(String msg) {
		status.setStyle("-fx-text-fill: #1a7f37;");
		status.setText(msg);
	}

	private void erro(String msg) {
		status.setStyle("-fx-text-fill: #c0392b;");
		status.setText(msg);
	}
}
