package br.com.estagio.fx;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Conexão JDBC com o banco criado pelo LabEng.sql. Ajuste usuário/senha se necessário. */
public final class Db {

	private static final String URL =
			"jdbc:mysql://localhost:3306/sistema_empresas?useSSL=false&allowPublicKeyRetrieval=true";
	private static final String USUARIO = "root";
	private static final String SENHA = "";

	private Db() {
	}

	public static Connection get() throws SQLException {
		return DriverManager.getConnection(URL, USUARIO, SENHA);
	}
}
