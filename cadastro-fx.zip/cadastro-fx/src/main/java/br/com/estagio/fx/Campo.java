package br.com.estagio.fx;

/** Descreve uma coluna da tabela: como aparece no formulário e como é validada. */
public record Campo(String rotulo, String coluna, Tipo tipo, boolean obrigatorio, int max, String refSql) {

	public enum Tipo { TEXTO, AREA, LONG, INTEIRO, DATA, REF }

	public static Campo texto(String rotulo, String coluna, boolean obrigatorio, int max) {
		return new Campo(rotulo, coluna, Tipo.TEXTO, obrigatorio, max, null);
	}

	public static Campo area(String rotulo, String coluna, boolean obrigatorio, int max) {
		return new Campo(rotulo, coluna, Tipo.AREA, obrigatorio, max, null);
	}

	/** BIGINT (CNPJ, CPF, CEP): aceita pontuação, só os dígitos são gravados. */
	public static Campo numero(String rotulo, String coluna, boolean obrigatorio) {
		return new Campo(rotulo, coluna, Tipo.LONG, obrigatorio, 0, null);
	}

	public static Campo inteiro(String rotulo, String coluna, boolean obrigatorio) {
		return new Campo(rotulo, coluna, Tipo.INTEIRO, obrigatorio, 0, null);
	}

	public static Campo data(String rotulo, String coluna, boolean obrigatorio) {
		return new Campo(rotulo, coluna, Tipo.DATA, obrigatorio, 0, null);
	}

	/** Chave estrangeira: refSql deve retornar (id, texto). */
	public static Campo ref(String rotulo, String coluna, boolean obrigatorio, String refSql) {
		return new Campo(rotulo, coluna, Tipo.REF, obrigatorio, 0, refSql);
	}
}
