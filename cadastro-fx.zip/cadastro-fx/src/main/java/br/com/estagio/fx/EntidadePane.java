package br.com.estagio.fx;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Control;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;

/** Página de cadastro de uma tabela: título, formulário em card e lista de registros em card. */
public class EntidadePane extends VBox {

	public record Opcao(long id, String texto) {
		@Override
		public String toString() {
			return texto;
		}
	}

	private final String tabela;
	private final Consumer<Map<String, Object>> validador;
	private final Map<Campo, Control> controles = new LinkedHashMap<>();
	private final TableView<List<String>> grade = new TableView<>();
	private final Label status = new Label();
	private final Label contador = new Label();

	public EntidadePane(String titulo, String subtitulo, String tabela, List<Campo> campos,
			Consumer<Map<String, Object>> validador) {
		this.tabela = tabela;
		this.validador = validador;
		getStyleClass().add("page");

		// ---- cabeçalho da página
		Label tituloPagina = new Label(titulo);
		tituloPagina.getStyleClass().add("page-title");
		Label subtituloPagina = new Label(subtitulo);
		subtituloPagina.getStyleClass().add("page-subtitle");
		VBox cabecalho = new VBox(3, tituloPagina, subtituloPagina);

		// ---- mensagem (aparece só quando há texto)
		status.setMaxWidth(Double.MAX_VALUE);
		status.setWrapText(true);
		status.visibleProperty().bind(status.textProperty().isNotEmpty());
		status.managedProperty().bind(status.textProperty().isNotEmpty());

		// ---- card do formulário
		GridPane form = new GridPane();
		form.setHgap(18);
		form.setVgap(14);
		ColumnConstraints metade = new ColumnConstraints();
		metade.setPercentWidth(50);
		form.getColumnConstraints().addAll(metade, metade);

		int linha = 0;
		int coluna = 0;
		for (Campo c : campos) {
			Control controle = criarControle(c);
			controle.setMaxWidth(Double.MAX_VALUE);
			controles.put(c, controle);
			Label rotulo = new Label(c.rotulo() + (c.obrigatorio() ? "  *" : ""));
			rotulo.getStyleClass().add("field-label");
			VBox caixa = new VBox(5, rotulo, controle);
			GridPane.setHgrow(caixa, Priority.ALWAYS);
			if (c.tipo() == Campo.Tipo.AREA) {
				if (coluna != 0) {
					linha++;
					coluna = 0;
				}
				form.add(caixa, 0, linha, 2, 1);
				linha++;
				continue;
			}
			form.add(caixa, coluna, linha);
			coluna++;
			if (coluna == 2) {
				coluna = 0;
				linha++;
			}
		}

		Button salvar = botao("Salvar", "btn-primary", e -> salvar());
		Button limpar = botao("Limpar", "btn-secondary", e -> limpar());
		HBox botoesForm = new HBox(10, salvar, limpar);

		VBox cardForm = new VBox(cabecalhoCard("Novo registro", new Label("*  campo obrigatório")), form, botoesForm);
		cardForm.getStyleClass().add("card");

		// ---- card da lista
		grade.setPrefHeight(300);
		grade.setMinHeight(220);
		grade.setPlaceholder(new Label("Nenhum registro cadastrado ainda."));
		Button atualizar = botao("Atualizar lista", "btn-secondary", e -> recarregar());
		Button excluir = botao("Excluir selecionado", "btn-danger", e -> excluir());
		HBox botoesLista = new HBox(10, atualizar, excluir);

		VBox cardLista = new VBox(cabecalhoCard("Registros cadastrados", contador), grade, botoesLista);
		cardLista.getStyleClass().add("card");

		getChildren().addAll(cabecalho, status, cardForm, cardLista);
	}

	// ---------------------------------------------------------------- montagem da tela

	private HBox cabecalhoCard(String titulo, Label dica) {
		Label t = new Label(titulo);
		t.getStyleClass().add("card-title");
		dica.getStyleClass().add("hint");
		Region espaco = new Region();
		HBox.setHgrow(espaco, Priority.ALWAYS);
		return new HBox(t, espaco, dica);
	}

	private Button botao(String texto, String estilo, javafx.event.EventHandler<javafx.event.ActionEvent> acao) {
		Button b = new Button(texto);
		b.getStyleClass().addAll("btn", estilo);
		b.setOnAction(acao);
		return b;
	}

	private Control criarControle(Campo c) {
		switch (c.tipo()) {
			case AREA: {
				TextArea area = new TextArea();
				area.setPrefRowCount(4);
				area.setWrapText(true);
				area.setPromptText("Descreva as funções e atividades do estágio...");
				return area;
			}
			case DATA: {
				DatePicker data = new DatePicker();
				data.setPromptText("dd/mm/aaaa");
				return data;
			}
			case REF: {
				ComboBox<Opcao> combo = new ComboBox<>();
				combo.setPromptText("Selecione...");
				return combo;
			}
			default: {
				TextField campo = new TextField();
				campo.setPromptText(c.tipo() == Campo.Tipo.LONG ? "somente números" : c.rotulo());
				return campo;
			}
		}
	}

	// ---------------------------------------------------------------- leitura e validação

	@SuppressWarnings("unchecked")
	private Object ler(Campo c, Control controle) {
		Object valor;
		try {
			switch (c.tipo()) {
				case AREA:
					valor = vazioParaNull(((TextArea) controle).getText());
					break;
				case LONG: {
					String digitos = ((TextField) controle).getText().replaceAll("\\D", "");
					valor = digitos.isEmpty() ? null : Long.parseLong(digitos);
					break;
				}
				case INTEIRO: {
					String texto = vazioParaNull(((TextField) controle).getText());
					valor = texto == null ? null : Integer.parseInt(texto);
					break;
				}
				case DATA: {
					LocalDate data = ((DatePicker) controle).getValue();
					valor = data == null ? null : Date.valueOf(data);
					break;
				}
				case REF: {
					Opcao opcao = ((ComboBox<Opcao>) controle).getValue();
					valor = opcao == null ? null : opcao.id();
					break;
				}
				default:
					valor = vazioParaNull(((TextField) controle).getText());
			}
		} catch (NumberFormatException ex) {
			throw new IllegalArgumentException(c.rotulo() + ": número inválido.");
		}
		if (valor == null && c.obrigatorio()) {
			throw new IllegalArgumentException(c.rotulo() + " é obrigatório.");
		}
		if (valor instanceof String s && c.max() > 0 && s.length() > c.max()) {
			throw new IllegalArgumentException(
					c.rotulo() + " deve ter no máximo " + c.max() + " caracteres (tem " + s.length() + ").");
		}
		return valor;
	}

	private static String vazioParaNull(String s) {
		if (s == null || s.isBlank()) {
			return null;
		}
		return s.trim();
	}

	// ---------------------------------------------------------------- ações

	private void salvar() {
		try {
			Map<String, Object> valores = new LinkedHashMap<>();
			for (Map.Entry<Campo, Control> e : controles.entrySet()) {
				valores.put(e.getKey().coluna(), ler(e.getKey(), e.getValue()));
			}
			if (validador != null) {
				validador.accept(valores);
			}
			String sql = "INSERT INTO " + tabela + " (" + String.join(", ", valores.keySet()) + ") VALUES ("
					+ String.join(", ", Collections.nCopies(valores.size(), "?")) + ")";
			try (Connection cn = Db.get();
					PreparedStatement ps = cn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
				int i = 1;
				for (Object v : valores.values()) {
					if (v == null) {
						ps.setNull(i++, Types.NULL);
					} else {
						ps.setObject(i++, v);
					}
				}
				ps.executeUpdate();
				try (ResultSet chaves = ps.getGeneratedKeys()) {
					long id = chaves.next() ? chaves.getLong(1) : -1;
					ok("Registro salvo com sucesso (id " + id + ").");
					System.out.println("[INSERT] " + tabela + " id=" + id + " -> " + valores);
				}
			}
			limpar();
			carregarGrade();
		} catch (IllegalArgumentException ex) {
			erro(ex.getMessage());
		} catch (SQLException ex) {
			erro("Erro no banco: " + ex.getMessage());
		}
	}

	private void excluir() {
		List<String> selecionado = grade.getSelectionModel().getSelectedItem();
		if (selecionado == null) {
			erro("Selecione uma linha na tabela para excluir.");
			return;
		}
		String id = selecionado.get(0);
		Alert confirmacao = new Alert(Alert.AlertType.CONFIRMATION,
				"Deseja realmente excluir o registro de id " + id + "?", ButtonType.YES, ButtonType.NO);
		confirmacao.setTitle("Confirmar exclusão");
		confirmacao.setHeaderText(null);
		confirmacao.showAndWait().filter(b -> b == ButtonType.YES).ifPresent(b -> {
			try (Connection cn = Db.get();
					PreparedStatement ps = cn.prepareStatement("DELETE FROM " + tabela + " WHERE id = ?")) {
				ps.setLong(1, Long.parseLong(id));
				ps.executeUpdate();
				ok("Registro " + id + " excluído.");
				carregarGrade();
			} catch (SQLException ex) {
				if (ex.getErrorCode() == 1451) {
					erro("Não é possível excluir: existem registros vinculados a este (ex.: contratos).");
				} else {
					erro("Erro no banco: " + ex.getMessage());
				}
			}
		});
	}

	private void limpar() {
		for (Control c : controles.values()) {
			if (c instanceof TextField t) {
				t.clear();
			} else if (c instanceof TextArea a) {
				a.clear();
			} else if (c instanceof DatePicker d) {
				d.setValue(null);
			} else if (c instanceof ComboBox<?> cb) {
				cb.getSelectionModel().clearSelection();
				cb.setValue(null);
			}
		}
	}

	// ---------------------------------------------------------------- carga de dados

	/** Recarrega as opções dos combos (chaves estrangeiras) e a tabela. */
	public void recarregar() {
		carregarOpcoes();
		carregarGrade();
	}

	@SuppressWarnings("unchecked")
	private void carregarOpcoes() {
		for (Map.Entry<Campo, Control> e : controles.entrySet()) {
			if (e.getKey().tipo() != Campo.Tipo.REF) {
				continue;
			}
			ComboBox<Opcao> combo = (ComboBox<Opcao>) e.getValue();
			Opcao anterior = combo.getValue();
			List<Opcao> opcoes = new ArrayList<>();
			try (Connection cn = Db.get();
					Statement st = cn.createStatement();
					ResultSet rs = st.executeQuery(e.getKey().refSql())) {
				while (rs.next()) {
					opcoes.add(new Opcao(rs.getLong(1), rs.getString(2)));
				}
			} catch (SQLException ex) {
				erro("Erro ao carregar opções: " + ex.getMessage());
				return;
			}
			combo.setItems(FXCollections.observableArrayList(opcoes));
			if (anterior != null) {
				opcoes.stream().filter(o -> o.id() == anterior.id()).findFirst().ifPresent(combo::setValue);
			}
		}
	}

	private void carregarGrade() {
		try (Connection cn = Db.get();
				Statement st = cn.createStatement();
				ResultSet rs = st.executeQuery("SELECT * FROM " + tabela + " ORDER BY id DESC")) {
			ResultSetMetaData md = rs.getMetaData();
			int n = md.getColumnCount();
			grade.getColumns().clear();
			for (int i = 0; i < n; i++) {
				final int idx = i;
				TableColumn<List<String>, String> col = new TableColumn<>(md.getColumnLabel(i + 1));
				col.setCellValueFactory(cd -> new SimpleStringProperty(cd.getValue().get(idx)));
				col.setPrefWidth(i == 0 ? 60 : 140);
				grade.getColumns().add(col);
			}
			List<List<String>> linhas = new ArrayList<>();
			while (rs.next()) {
				List<String> linha = new ArrayList<>();
				for (int i = 1; i <= n; i++) {
					String s = rs.getString(i);
					linha.add(s == null ? "" : s);
				}
				linhas.add(linha);
			}
			grade.setItems(FXCollections.observableArrayList(linhas));
			contador.setText(linhas.size() == 1 ? "1 registro" : linhas.size() + " registros");
		} catch (SQLException ex) {
			erro("Erro ao ler " + tabela + ": " + ex.getMessage());
		}
	}

	// ---------------------------------------------------------------- mensagens

	private void ok(String msg) {
		status.getStyleClass().setAll("label", "status", "status-ok");
		status.setText("✔  " + msg);
	}

	private void erro(String msg) {
		status.getStyleClass().setAll("label", "status", "status-erro");
		status.setText("✖  " + msg);
	}
}
