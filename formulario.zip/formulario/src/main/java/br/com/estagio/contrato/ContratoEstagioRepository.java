package br.com.estagio.contrato;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface ContratoEstagioRepository extends JpaRepository<ContratoEstagio, Long> {
}
