package br.com.estagio.empresa;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Tabela: dados_empresa */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmpresaDTO {

    private Long id;

    @NotNull(message = "CNPJ é obrigatório")
    private Long cnpj;

    @NotBlank(message = "Razão social é obrigatória")
    @Size(max = 150, message = "Razão social deve ter no máximo 150 caracteres")
    private String razaoSocial;

    @Size(max = 100, message = "Área de atuação deve ter no máximo 100 caracteres")
    private String areaAtuacao;

    @Size(max = 100, message = "Cidade deve ter no máximo 100 caracteres")
    private String cidade;

    private Long cep;

    @Email(message = "E-mail inválido")
    @Size(max = 150, message = "E-mail deve ter no máximo 150 caracteres")
    private String email;

    @Size(max = 200, message = "Site deve ter no máximo 200 caracteres")
    private String site;

    @Size(max = 30, message = "Telefone deve ter no máximo 30 caracteres")
    private String fone;

    @Size(max = 255, message = "Link Trabalhe Conosco deve ter no máximo 255 caracteres")
    private String trabalheConosco;
}
