package br.com.estagio.empresa;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizacaoEmpresa(
	@NotNull
	Long id,
	Long cnpj,
	String razaoSocial,
	String areaAtuacao,
	String cidade,
	Long cep,
	String email,
	String site,
	String fone,
	String trabalheConosco) {
}
