package br.com.estagio.empresa;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "dados_empresa")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id")
public class Empresa implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull
	private Long cnpj;

	@NotBlank
	@Column(name = "razao_social")
	private String razaoSocial;

	@Column(name = "area_atuacao")
	private String areaAtuacao;

	private String cidade;
	private Long cep;
	private String email;
	private String site;
	private String fone;

	@Column(name = "trabalhe_conosco")
	private String trabalheConosco;

	public Empresa(DadosCadastroEmpresa dados) {
		this.cnpj = dados.cnpj();
		this.razaoSocial = dados.razaoSocial();
		this.areaAtuacao = dados.areaAtuacao();
		this.cidade = dados.cidade();
		this.cep = dados.cep();
		this.email = dados.email();
		this.site = dados.site();
		this.fone = dados.fone();
		this.trabalheConosco = dados.trabalheConosco();
	}

	public void atualizarInformacoes(DadosAtualizacaoEmpresa dados) {
		if (dados.cnpj() != null) this.cnpj = dados.cnpj();
		if (dados.razaoSocial() != null) this.razaoSocial = dados.razaoSocial();
		if (dados.areaAtuacao() != null) this.areaAtuacao = dados.areaAtuacao();
		if (dados.cidade() != null) this.cidade = dados.cidade();
		if (dados.cep() != null) this.cep = dados.cep();
		if (dados.email() != null) this.email = dados.email();
		if (dados.site() != null) this.site = dados.site();
		if (dados.fone() != null) this.fone = dados.fone();
		if (dados.trabalheConosco() != null) this.trabalheConosco = dados.trabalheConosco();
	}
}
