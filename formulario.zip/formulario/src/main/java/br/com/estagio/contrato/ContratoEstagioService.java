package br.com.estagio.contrato;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class ContratoEstagioService {

	@Autowired
	private ContratoEstagioRepository contratoEstagioRepository;

	public List<ContratoEstagio> getAllContratoEstagios() {
		return contratoEstagioRepository.findAll(Sort.by("inicioContrato").descending());
	}

	public ContratoEstagio getContratoEstagioById(Long id) {
		return contratoEstagioRepository.getReferenceById(id);
	}
}
