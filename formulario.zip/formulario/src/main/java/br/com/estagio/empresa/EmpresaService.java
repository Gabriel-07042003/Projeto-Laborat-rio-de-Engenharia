package br.com.estagio.empresa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class EmpresaService {

	@Autowired
	private EmpresaRepository empresaRepository;

	public List<Empresa> getAllEmpresas() {
		return empresaRepository.findAll(Sort.by("razaoSocial").ascending());
	}

	public Empresa getEmpresaById(Long id) {
		return empresaRepository.getReferenceById(id);
	}
}
