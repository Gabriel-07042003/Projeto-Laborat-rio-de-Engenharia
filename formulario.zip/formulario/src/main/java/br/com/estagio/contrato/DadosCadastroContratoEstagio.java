package br.com.estagio.contrato;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;

public record DadosCadastroContratoEstagio(
	@NotNull
	Long empresaId,
	@NotNull
	Long estagiarioId,
	@NotNull
	LocalDate inicioContrato,
	@NotNull
	LocalDate terminoContrato,
	String cargaHoraria,
	String areaSetorEstagio,
	String funcoesAtividades,
	String supervisorResponsavel,
	String cargoSupervisor) {
}
