package br.com.estagio.estagiario;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/estagiario")
public class EstagiarioController {

	@Autowired
	private EstagiarioRepository estagiarioRepository;

	@GetMapping("/formulario/{id}")
	public String carregaPaginaFormulario(@PathVariable("id") Long id,
			RedirectAttributes redirectAttributes,
			Model model) {
		try {
			Estagiario estagiario = estagiarioRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Estagiário não encontrado"));
			model.addAttribute("estagiario", estagiario);
			return "estagiario/formulario";
		} catch (EntityNotFoundException e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/estagiario";
		}
	}

	@GetMapping("/formulario")
	public String novoEstagiario(Model model) {
		model.addAttribute("estagiario", new Estagiario());
		return "estagiario/formulario";
	}

	@GetMapping
	public String carregaPaginaListagem(Model model) {
		model.addAttribute("activePage", "estagiario");
		model.addAttribute("lista", estagiarioRepository.findAll(Sort.by("nomeCompleto").ascending()));
		return "estagiario/listagem";
	}

	@PostMapping("/salvar")
	public String salvarEstagiario(@Valid @ModelAttribute("estagiario") Estagiario estagiario,
			BindingResult result,
			RedirectAttributes redirectAttributes) {
		if (result.hasErrors()) {
			return "estagiario/formulario";
		}
		try {
			estagiarioRepository.save(estagiario);
			String mensagem = estagiario.getId() != null
					? "Estagiário '" + estagiario.getNomeCompleto() + "' atualizado com sucesso!"
					: "Estagiário '" + estagiario.getNomeCompleto() + "' criado com sucesso!";
			redirectAttributes.addFlashAttribute("message", mensagem);
			return "redirect:/estagiario";
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Erro ao salvar estagiário: " + e.getMessage());
			return "redirect:/estagiario/formulario"
					+ (estagiario.getId() != null ? "/" + estagiario.getId() : "");
		}
	}

	@GetMapping("/delete/{id}")
	public String deleteEstagiario(@PathVariable("id") Long id,
			RedirectAttributes redirectAttributes) {
		try {
			estagiarioRepository.deleteById(id);
			redirectAttributes.addFlashAttribute("message", "O estagiário id=" + id + " foi apagado!");
		} catch (DataIntegrityViolationException e) {
			redirectAttributes.addFlashAttribute("error",
					"Não é possível apagar: existem contratos vinculados a este estagiário.");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
		}
		return "redirect:/estagiario";
	}
}
