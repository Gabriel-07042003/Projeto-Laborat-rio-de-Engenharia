package br.com.estagio.estagiario;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class EstagiarioService {

	@Autowired
	private EstagiarioRepository estagiarioRepository;

	public List<Estagiario> getAllEstagiarios() {
		return estagiarioRepository.findAll(Sort.by("nomeCompleto").ascending());
	}

	public Estagiario getEstagiarioById(Long id) {
		return estagiarioRepository.getReferenceById(id);
	}
}
