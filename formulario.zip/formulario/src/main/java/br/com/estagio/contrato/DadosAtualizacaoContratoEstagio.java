package br.com.estagio.contrato;

import java.time.LocalDate;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizacaoContratoEstagio(
	@NotNull
	Long id,
	Long empresaId,
	Long estagiarioId,
	LocalDate inicioContrato,
	LocalDate terminoContrato,
	String cargaHoraria,
	String areaSetorEstagio,
	String funcoesAtividades,
	String supervisorResponsavel,
	String cargoSupervisor) {
}
