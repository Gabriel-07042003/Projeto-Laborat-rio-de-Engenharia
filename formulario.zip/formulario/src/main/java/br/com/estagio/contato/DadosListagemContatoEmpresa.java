package br.com.estagio.contato;

public record DadosListagemContatoEmpresa(
	Long id,
	Long empresaId,
	String razaoSocialEmpresa,
	String nomeContato,
	String cargoContato,
	String foneContato,
	String areaDepartamento,
	String linkedin) {

	public DadosListagemContatoEmpresa(ContatoEmpresa contato) {
		this(contato.getId(),
			 contato.getEmpresa().getId(),
			 contato.getEmpresa().getRazaoSocial(),
			 contato.getNomeContato(),
			 contato.getCargoContato(),
			 contato.getFoneContato(),
			 contato.getAreaDepartamento(),
			 contato.getLinkedin());
	}
}
