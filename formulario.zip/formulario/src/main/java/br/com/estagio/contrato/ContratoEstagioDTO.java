package br.com.estagio.contrato;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Tabela: contrato_estagio */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContratoEstagioDTO {

    private Long id;

    @NotNull(message = "Empresa é obrigatória")
    private Long empresaId;

    @NotNull(message = "Estagiário é obrigatório")
    private Long estagiarioId;

    @NotNull(message = "Início do contrato é obrigatório")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate inicioContrato;

    @NotNull(message = "Término do contrato é obrigatório")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate terminoContrato;

    @Size(max = 50, message = "Carga horária deve ter no máximo 50 caracteres")
    private String cargaHoraria;

    @Size(max = 100, message = "Área/setor do estágio deve ter no máximo 100 caracteres")
    private String areaSetorEstagio;

    @Size(max = 65535, message = "Funções e atividades excedeu o tamanho máximo")
    private String funcoesAtividades;

    @Size(max = 150, message = "Supervisor deve ter no máximo 150 caracteres")
    private String supervisorResponsavel;

    @Size(max = 100, message = "Cargo do supervisor deve ter no máximo 100 caracteres")
    private String cargoSupervisor;
}
