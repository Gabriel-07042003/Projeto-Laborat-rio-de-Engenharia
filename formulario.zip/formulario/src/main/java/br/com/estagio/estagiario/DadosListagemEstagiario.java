package br.com.estagio.estagiario;

public record DadosListagemEstagiario(
		Long id,
		String nomeCompleto,
		Long cpf,
		String fone,
		String email,
		String curso,
		Integer semestre,
		String periodo) {

	public DadosListagemEstagiario(Estagiario estagiario) {
		this(estagiario.getId(),
			 estagiario.getNomeCompleto(),
			 estagiario.getCpf(),
			 estagiario.getFone(),
			 estagiario.getEmail(),
			 estagiario.getCurso(),
			 estagiario.getSemestre(),
			 estagiario.getPeriodo());
	}
}
