package br.com.estagio.contato;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class ContatoEmpresaService {

	@Autowired
	private ContatoEmpresaRepository contatoEmpresaRepository;

	public List<ContatoEmpresa> getAllContatoEmpresas() {
		return contatoEmpresaRepository.findAll(Sort.by("nomeContato").ascending());
	}

	public ContatoEmpresa getContatoEmpresaById(Long id) {
		return contatoEmpresaRepository.getReferenceById(id);
	}
}
