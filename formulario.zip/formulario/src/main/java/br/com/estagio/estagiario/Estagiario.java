package br.com.estagio.estagiario;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "dados_estagiario")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id")
public class Estagiario implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "nome_completo")
	private String nomeCompleto;

	private Long cpf;
	private String fone;
	private String email;
	private String curso;
	private Integer semestre;
	private String periodo;

	public Estagiario(DadosCadastroEstagiario dados) {
		this.nomeCompleto = dados.nomeCompleto();
		this.cpf = dados.cpf();
		this.fone = dados.fone();
		this.email = dados.email();
		this.curso = dados.curso();
		this.semestre = dados.semestre();
		this.periodo = dados.periodo();
	}

	public void atualizarInformacoes(DadosAtualizacaoEstagiario dados) {
		if (dados.nomeCompleto() != null) this.nomeCompleto = dados.nomeCompleto();
		if (dados.cpf() != null) this.cpf = dados.cpf();
		if (dados.fone() != null) this.fone = dados.fone();
		if (dados.email() != null) this.email = dados.email();
		if (dados.curso() != null) this.curso = dados.curso();
		if (dados.semestre() != null) this.semestre = dados.semestre();
		if (dados.periodo() != null) this.periodo = dados.periodo();
	}
}
