package br.com.estagio.contato;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.estagio.empresa.Empresa;
import br.com.estagio.empresa.EmpresaRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/contato")
public class ContatoEmpresaController {

	@Autowired
	private ContatoEmpresaRepository contatoRepository;

	@Autowired
	private EmpresaRepository empresaRepository;

	private void carregaEmpresas(Model model) {
		model.addAttribute("empresas", empresaRepository.findAll(Sort.by("razaoSocial").ascending()));
	}

	@GetMapping("/formulario/{id}")
	public String carregaPaginaFormulario(@PathVariable("id") Long id,
			RedirectAttributes redirectAttributes,
			Model model) {
		try {
			ContatoEmpresa contato = contatoRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Contato não encontrado"));
			model.addAttribute("contato", contato);
			carregaEmpresas(model);
			return "contato/formulario";
		} catch (EntityNotFoundException e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/contato";
		}
	}

	@GetMapping("/formulario")
	public String novoContato(Model model) {
		ContatoEmpresa contato = new ContatoEmpresa();
		contato.setEmpresa(new Empresa()); // necessário para o binding de empresa.id no select
		model.addAttribute("contato", contato);
		carregaEmpresas(model);
		return "contato/formulario";
	}

	@GetMapping
	public String carregaPaginaListagem(Model model) {
		model.addAttribute("activePage", "contato");
		model.addAttribute("lista", contatoRepository.findAll(Sort.by("nomeContato").ascending())
				.stream().map(DadosListagemContatoEmpresa::new).toList());
		return "contato/listagem";
	}

	@PostMapping("/salvar")
	public String salvarContato(@Valid @ModelAttribute("contato") ContatoEmpresa contato,
			BindingResult result,
			Model model,
			RedirectAttributes redirectAttributes) {
		if (result.hasErrors()) {
			carregaEmpresas(model);
			return "contato/formulario";
		}
		try {
			contatoRepository.save(contato);
			String mensagem = contato.getId() != null
					? "Contato '" + contato.getNomeContato() + "' salvo com sucesso!"
					: "Contato '" + contato.getNomeContato() + "' criado com sucesso!";
			redirectAttributes.addFlashAttribute("message", mensagem);
			return "redirect:/contato";
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Erro ao salvar contato: " + e.getMessage());
			return "redirect:/contato/formulario"
					+ (contato.getId() != null ? "/" + contato.getId() : "");
		}
	}

	@GetMapping("/delete/{id}")
	public String deleteContato(@PathVariable("id") Long id,
			RedirectAttributes redirectAttributes) {
		try {
			contatoRepository.deleteById(id);
			redirectAttributes.addFlashAttribute("message", "O contato id=" + id + " foi apagado!");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
		}
		return "redirect:/contato";
	}
}
