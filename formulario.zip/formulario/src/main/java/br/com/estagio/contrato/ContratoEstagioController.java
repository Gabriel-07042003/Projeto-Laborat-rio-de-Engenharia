package br.com.estagio.contrato;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.estagio.empresa.Empresa;
import br.com.estagio.empresa.EmpresaRepository;
import br.com.estagio.estagiario.Estagiario;
import br.com.estagio.estagiario.EstagiarioRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/contrato")
public class ContratoEstagioController {

	@Autowired
	private ContratoEstagioRepository contratoRepository;

	@Autowired
	private EmpresaRepository empresaRepository;

	@Autowired
	private EstagiarioRepository estagiarioRepository;

	private void carregaListasAuxiliares(Model model) {
		model.addAttribute("empresas", empresaRepository.findAll(Sort.by("razaoSocial").ascending()));
		model.addAttribute("estagiarios", estagiarioRepository.findAll(Sort.by("nomeCompleto").ascending()));
	}

	@GetMapping("/formulario/{id}")
	public String carregaPaginaFormulario(@PathVariable("id") Long id,
			RedirectAttributes redirectAttributes,
			Model model) {
		try {
			ContratoEstagio contrato = contratoRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Contrato não encontrado"));
			model.addAttribute("contrato", contrato);
			carregaListasAuxiliares(model);
			return "contrato/formulario";
		} catch (EntityNotFoundException e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/contrato";
		}
	}

	@GetMapping("/formulario")
	public String novoContrato(Model model) {
		ContratoEstagio contrato = new ContratoEstagio();
		contrato.setEmpresa(new Empresa());         // necessário para o binding de empresa.id
		contrato.setEstagiario(new Estagiario());   // necessário para o binding de estagiario.id
		model.addAttribute("contrato", contrato);
		carregaListasAuxiliares(model);
		return "contrato/formulario";
	}

	@GetMapping
	public String carregaPaginaListagem(Model model) {
		model.addAttribute("activePage", "contrato");
		model.addAttribute("lista", contratoRepository.findAll(Sort.by("inicioContrato").descending())
				.stream().map(DadosListagemContratoEstagio::new).toList());
		return "contrato/listagem";
	}

	@PostMapping("/salvar")
	public String salvarContrato(@Valid @ModelAttribute("contrato") ContratoEstagio contrato,
			BindingResult result,
			Model model,
			RedirectAttributes redirectAttributes) {
		if (contrato.getInicioContrato() != null && contrato.getTerminoContrato() != null
				&& contrato.getTerminoContrato().isBefore(contrato.getInicioContrato())) {
			result.rejectValue("terminoContrato", "data.invalida",
					"O término do contrato não pode ser anterior ao início.");
		}
		if (result.hasErrors()) {
			carregaListasAuxiliares(model);
			return "contrato/formulario";
		}
		try {
			contratoRepository.save(contrato);
			redirectAttributes.addFlashAttribute("message",
					contrato.getId() != null ? "Contrato salvo com sucesso!" : "Contrato criado com sucesso!");
			return "redirect:/contrato";
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Erro ao salvar contrato: " + e.getMessage());
			return "redirect:/contrato/formulario"
					+ (contrato.getId() != null ? "/" + contrato.getId() : "");
		}
	}

	@GetMapping("/delete/{id}")
	public String deleteContrato(@PathVariable("id") Long id,
			RedirectAttributes redirectAttributes) {
		try {
			contratoRepository.deleteById(id);
			redirectAttributes.addFlashAttribute("message", "O contrato id=" + id + " foi apagado!");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
		}
		return "redirect:/contrato";
	}
}
