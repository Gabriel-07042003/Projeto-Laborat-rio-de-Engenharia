package br.com.estagio.estagiario;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** Tabela: dados_estagiario */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EstagiarioDTO {

    private Long id;

    @NotBlank(message = "Nome completo é obrigatório")
    @Size(max = 150, message = "Nome completo deve ter no máximo 150 caracteres")
    private String nomeCompleto;

    @NotNull(message = "CPF é obrigatório")
    private Long cpf;

    @Size(max = 30, message = "Telefone deve ter no máximo 30 caracteres")
    private String fone;

    @Email(message = "E-mail inválido")
    @Size(max = 150, message = "E-mail deve ter no máximo 150 caracteres")
    private String email;

    @Size(max = 100, message = "Curso deve ter no máximo 100 caracteres")
    private String curso;

    private Integer semestre;

    @Size(max = 10, message = "Período deve ter no máximo 10 caracteres")
    private String periodo;
}
