package br.com.estagio.estagiario;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosCadastroEstagiario(
		@NotBlank
		String nomeCompleto,
		@NotNull
		Long cpf,
		String fone,
		String email,
		String curso,
		Integer semestre,
		String periodo) {
}
