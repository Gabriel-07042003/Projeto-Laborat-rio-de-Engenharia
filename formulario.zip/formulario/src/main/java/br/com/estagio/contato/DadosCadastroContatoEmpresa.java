package br.com.estagio.contato;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosCadastroContatoEmpresa(
	@NotNull
	Long empresaId,
	@NotBlank
	String nomeContato,
	String cargoContato,
	String foneContato,
	String areaDepartamento,
	String linkedin) {
}
