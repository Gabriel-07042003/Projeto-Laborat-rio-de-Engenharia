package br.com.estagio.estagiario;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public interface EstagiarioRepository extends JpaRepository<Estagiario, Long> {
}
