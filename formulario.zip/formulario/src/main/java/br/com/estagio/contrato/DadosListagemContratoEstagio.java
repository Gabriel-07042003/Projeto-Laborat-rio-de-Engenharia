package br.com.estagio.contrato;

import java.time.LocalDate;

public record DadosListagemContratoEstagio(
	Long id,
	Long empresaId,
	String razaoSocialEmpresa,
	Long estagiarioId,
	String nomeEstagiario,
	LocalDate inicioContrato,
	LocalDate terminoContrato,
	String cargaHoraria,
	String areaSetorEstagio,
	String funcoesAtividades,
	String supervisorResponsavel,
	String cargoSupervisor) {

	public DadosListagemContratoEstagio(ContratoEstagio contrato) {
		this(contrato.getId(),
			 contrato.getEmpresa().getId(),
			 contrato.getEmpresa().getRazaoSocial(),
			 contrato.getEstagiario().getId(),
			 contrato.getEstagiario().getNomeCompleto(),
			 contrato.getInicioContrato(),
			 contrato.getTerminoContrato(),
			 contrato.getCargaHoraria(),
			 contrato.getAreaSetorEstagio(),
			 contrato.getFuncoesAtividades(),
			 contrato.getSupervisorResponsavel(),
			 contrato.getCargoSupervisor());
	}
}
