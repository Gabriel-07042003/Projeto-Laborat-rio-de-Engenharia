package br.com.estagio.empresa;

public record DadosListagemEmpresa(
	Long id,
	Long cnpj,
	String razaoSocial,
	String areaAtuacao,
	String cidade,
	Long cep,
	String email,
	String site,
	String fone,
	String trabalheConosco) {

	public DadosListagemEmpresa(Empresa empresa) {
		this(empresa.getId(),
			 empresa.getCnpj(),
			 empresa.getRazaoSocial(),
			 empresa.getAreaAtuacao(),
			 empresa.getCidade(),
			 empresa.getCep(),
			 empresa.getEmail(),
			 empresa.getSite(),
			 empresa.getFone(),
			 empresa.getTrabalheConosco());
	}
}
