package br.com.estagio.empresa;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosCadastroEmpresa(
	@NotNull
	Long cnpj,
	@NotBlank
	String razaoSocial,
	String areaAtuacao,
	String cidade,
	Long cep,
	String email,
	String site,
	String fone,
	String trabalheConosco) {
}
