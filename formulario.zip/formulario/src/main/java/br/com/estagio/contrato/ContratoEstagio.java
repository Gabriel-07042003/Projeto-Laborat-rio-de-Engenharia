package br.com.estagio.contrato;

import java.io.Serializable;
import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import br.com.estagio.empresa.Empresa;
import br.com.estagio.estagiario.Estagiario;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "contrato_estagio")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id")
public class ContratoEstagio implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "empresa_id", nullable = false)
	private Empresa empresa;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "estagiario_id", nullable = false)
	private Estagiario estagiario;

	@NotNull
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "inicio_contrato")
	private LocalDate inicioContrato;

	@NotNull
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column(name = "termino_contrato")
	private LocalDate terminoContrato;

	@Column(name = "carga_horaria")
	private String cargaHoraria;

	@Column(name = "area_setor_estagio")
	private String areaSetorEstagio;

	@Column(name = "funcoes_atividades", columnDefinition = "TEXT")
	private String funcoesAtividades;

	@Column(name = "supervisor_responsavel")
	private String supervisorResponsavel;

	@Column(name = "cargo_supervisor")
	private String cargoSupervisor;

	public ContratoEstagio(DadosCadastroContratoEstagio dados, Empresa empresa, Estagiario estagiario) {
		this.empresa = empresa;
		this.estagiario = estagiario;
		this.inicioContrato = dados.inicioContrato();
		this.terminoContrato = dados.terminoContrato();
		this.cargaHoraria = dados.cargaHoraria();
		this.areaSetorEstagio = dados.areaSetorEstagio();
		this.funcoesAtividades = dados.funcoesAtividades();
		this.supervisorResponsavel = dados.supervisorResponsavel();
		this.cargoSupervisor = dados.cargoSupervisor();
	}

	/** Passe novaEmpresa/novoEstagiario apenas se os respectivos ids do DTO vierem preenchidos; senão null. */
	public void atualizarInformacoes(DadosAtualizacaoContratoEstagio dados,
			Empresa novaEmpresa, Estagiario novoEstagiario) {
		if (novaEmpresa != null) this.empresa = novaEmpresa;
		if (novoEstagiario != null) this.estagiario = novoEstagiario;
		if (dados.inicioContrato() != null) this.inicioContrato = dados.inicioContrato();
		if (dados.terminoContrato() != null) this.terminoContrato = dados.terminoContrato();
		if (dados.cargaHoraria() != null) this.cargaHoraria = dados.cargaHoraria();
		if (dados.areaSetorEstagio() != null) this.areaSetorEstagio = dados.areaSetorEstagio();
		if (dados.funcoesAtividades() != null) this.funcoesAtividades = dados.funcoesAtividades();
		if (dados.supervisorResponsavel() != null) this.supervisorResponsavel = dados.supervisorResponsavel();
		if (dados.cargoSupervisor() != null) this.cargoSupervisor = dados.cargoSupervisor();
	}
}
