package br.com.estagio.empresa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/empresa")
public class EmpresaController {

	@Autowired
	private EmpresaRepository empresaRepository;

	@GetMapping("/formulario/{id}")
	public String carregaPaginaFormulario(@PathVariable("id") Long id,
			RedirectAttributes redirectAttributes,
			Model model) {
		try {
			Empresa empresa = empresaRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Empresa não encontrada"));
			model.addAttribute("empresa", empresa);
			return "empresa/formulario";
		} catch (EntityNotFoundException e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
			return "redirect:/empresa";
		}
	}

	@GetMapping("/formulario")
	public String novaEmpresa(Model model) {
		model.addAttribute("empresa", new Empresa());
		return "empresa/formulario";
	}

	@GetMapping
	public String carregaPaginaListagem(Model model) {
		model.addAttribute("activePage", "empresa");
		model.addAttribute("lista", empresaRepository.findAll(Sort.by("razaoSocial").ascending())
				.stream().map(DadosListagemEmpresa::new).toList());
		return "empresa/listagem";
	}

	@PostMapping("/salvar")
	public String salvarEmpresa(@Valid @ModelAttribute("empresa") Empresa empresa,
			BindingResult result,
			RedirectAttributes redirectAttributes) {
		if (result.hasErrors()) {
			return "empresa/formulario";
		}
		try {
			empresaRepository.save(empresa);
			String mensagem = empresa.getId() != null
					? "Empresa '" + empresa.getRazaoSocial() + "' salva com sucesso!"
					: "Empresa '" + empresa.getRazaoSocial() + "' criada com sucesso!";
			redirectAttributes.addFlashAttribute("message", mensagem);
			return "redirect:/empresa";
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", "Erro ao salvar empresa: " + e.getMessage());
			return "redirect:/empresa/formulario"
					+ (empresa.getId() != null ? "/" + empresa.getId() : "");
		}
	}

	@GetMapping("/delete/{id}")
	public String deleteEmpresa(@PathVariable("id") Long id,
			RedirectAttributes redirectAttributes) {
		try {
			empresaRepository.deleteById(id);
			redirectAttributes.addFlashAttribute("message", "A empresa id=" + id + " foi apagada!");
		} catch (DataIntegrityViolationException e) {
			redirectAttributes.addFlashAttribute("error",
					"Não é possível apagar: existem contratos vinculados a esta empresa.");
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute("error", e.getMessage());
		}
		return "redirect:/empresa";
	}
}
