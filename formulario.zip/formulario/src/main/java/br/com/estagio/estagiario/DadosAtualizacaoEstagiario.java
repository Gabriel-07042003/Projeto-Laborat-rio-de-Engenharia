package br.com.estagio.estagiario;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizacaoEstagiario(
		@NotNull
		Long id,
		String nomeCompleto,
		Long cpf,
		String fone,
		String email,
		String curso,
		Integer semestre,
		String periodo) {
}
