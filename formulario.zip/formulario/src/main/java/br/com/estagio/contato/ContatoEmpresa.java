package br.com.estagio.contato;

import java.io.Serializable;

import br.com.estagio.empresa.Empresa;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "contato_empresa")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(of = "id")
public class ContatoEmpresa implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotNull
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "empresa_id", nullable = false)
	private Empresa empresa;

	@NotBlank
	@Column(name = "nome_contato")
	private String nomeContato;

	@Column(name = "cargo_contato")
	private String cargoContato;

	@Column(name = "fone_contato")
	private String foneContato;

	@Column(name = "area_departamento")
	private String areaDepartamento;

	private String linkedin;

	public ContatoEmpresa(DadosCadastroContatoEmpresa dados, Empresa empresa) {
		this.empresa = empresa;
		this.nomeContato = dados.nomeContato();
		this.cargoContato = dados.cargoContato();
		this.foneContato = dados.foneContato();
		this.areaDepartamento = dados.areaDepartamento();
		this.linkedin = dados.linkedin();
	}

	/** Passe a nova empresa apenas se dados.empresaId() != null; caso contrário passe null. */
	public void atualizarInformacoes(DadosAtualizacaoContatoEmpresa dados, Empresa novaEmpresa) {
		if (novaEmpresa != null) this.empresa = novaEmpresa;
		if (dados.nomeContato() != null) this.nomeContato = dados.nomeContato();
		if (dados.cargoContato() != null) this.cargoContato = dados.cargoContato();
		if (dados.foneContato() != null) this.foneContato = dados.foneContato();
		if (dados.areaDepartamento() != null) this.areaDepartamento = dados.areaDepartamento();
		if (dados.linkedin() != null) this.linkedin = dados.linkedin();
	}
}
