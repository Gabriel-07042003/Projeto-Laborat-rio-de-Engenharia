package br.com.estagio.contato;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizacaoContatoEmpresa(
	@NotNull
	Long id,
	Long empresaId,
	String nomeContato,
	String cargoContato,
	String foneContato,
	String areaDepartamento,
	String linkedin) {
}
