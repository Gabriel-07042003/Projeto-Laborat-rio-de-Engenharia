package br.com.estagio.contato;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ContatoEmpresaDTO {

    private Long id;

    @NotNull(message = "Empresa é obrigatória")
    private Long empresaId;

    @NotBlank(message = "Nome do contato é obrigatório")
    @Size(max = 150, message = "Nome do contato deve ter no máximo 150 caracteres")
    private String nomeContato;

    @Size(max = 100, message = "Cargo deve ter no máximo 100 caracteres")
    private String cargoContato;

    @Size(max = 30, message = "Telefone deve ter no máximo 30 caracteres")
    private String foneContato;

    @Size(max = 100, message = "Área/departamento deve ter no máximo 100 caracteres")
    private String areaDepartamento;

    @Size(max = 255, message = "LinkedIn deve ter no máximo 255 caracteres")
    private String linkedin;
}
